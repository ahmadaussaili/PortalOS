-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: portalos
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `desktop`
--

DROP TABLE IF EXISTS `desktop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `desktop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerID` int(11) NOT NULL,
  `rootDirID` int(11) NOT NULL,
  `background` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `desktop`
--

LOCK TABLES `desktop` WRITE;
/*!40000 ALTER TABLE `desktop` DISABLE KEYS */;
INSERT INTO `desktop` VALUES (1,5,1,'https://www.pixafy.com/wp-content/uploads/2014/05/win-xp.jpg');
/*!40000 ALTER TABLE `desktop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dir`
--

DROP TABLE IF EXISTS `dir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dir` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `JSON` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dir`
--

LOCK TABLES `dir` WRITE;
/*!40000 ALTER TABLE `dir` DISABLE KEYS */;
INSERT INTO `dir` VALUES (1,'{}');
/*!40000 ALTER TABLE `dir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `hash` varchar(684) DEFAULT NULL,
  `profileimg` varchar(255) DEFAULT NULL,
  `sid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'jmjbower@gmail.com',NULL,NULL,NULL,NULL),(5,'bob@bob.com','C1WST0Vi1RS7y9X/ZNc7NGQTlgRQKLpiUzzuFTb1E60qbSyfxdbL+TJk5QNM/adBwIyAoWIk0QNpJal4hPfX3OfUC1r48iNv6HTyeD0rPK0OfNXIL918kTl74oKMSFvWnv2tHs7rKkxePek6t2U68ivxrOUbwyBGCWUYM9ja0SQ=','BwO8If3ChNHmE1sMStlpFgy3/jMQpLh/rI4mSwA+K19L2aoR4pYLvXY2nHtiOdvEV8oywy+80rORVy1RKulcJnzd9K25i1hMGrBnR4l1YqE87FNUyPNtc8rG8g0q7GdDGfy3ZdEexhDnj9fpf/hTpj8TXeyWxyMkkjNyaLR+OR3GsTvXDJPz/HOWxnFkdfq+31YlURLsmBX/+KOxxzrwMhnlbiW+FZNeS05+IVv6fRo4ZvteOHcygAWq6x9AL1dN3UQw3iw7bCO74tiswB5UKu5S8NpIbJmRKdXMeILPzPSbxElWhh6Y+/+g1jZsYKv1efeL1v+QY/T2mFFypCshYY72H572KfJLwxKsYzxQ2Kg9p9OzHw0zrOGdXb+/iHZYUS/zQRRHC4AaHDKUcPUBMq/vLzlDnSgjgcD9wCQV7YE3A6zv1fH4nK7jEHYLVxWWp32LwnZrLmkl212kWEgUq0RI81+HLvM7/zCr4oqwSnhu4OR+h1hysMl+hzdlSjJ8lnXmCb2xUo9jI8HHyQimA7aF9qYFfsrZSVGTIENDZe8W5e1yQW4BddQG+oxRQVV5nAaqLEqhw4jvmZFCposrzGYjXDgb8FG4p9aXfCJFJCHm5IjkR4ncqLjmp0HVIxmhrf/loAgFCJvUC07lre9cXrXDehF17xiaum8xyTbYXaQ=',NULL,'YD4oNw2o+xAWha/bw2gJObfALLxl53lXKmOqZ6ZHehcwx3JL+zSw+lwVCiZmXPOizZJR4Mhm7tBeyrQ7pDBPjr7w9IbZ3eHxfX+yl3foOsqvxrGJliQEjZW29HUJp/bb9PJ+ilJrBtuAexyeDWA6/UvMOvYGdS+/A371oBWQcSA=');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-17 17:21:52
